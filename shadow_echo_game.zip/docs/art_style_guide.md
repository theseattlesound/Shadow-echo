# Shadow Echo - Art Style Guide

## Visual Identity
Shadow Echo employs a distinctive visual style characterized by minimalism, strong silhouettes, and atmospheric lighting. The art direction draws inspiration from Playdead's Inside while establishing its own unique identity through specific color treatments and environmental design.

## Color Palette

### Primary Palette
- **Deep Blues** (#0A1921, #152A35, #1D3B4D): For backgrounds and distant elements
- **Muted Grays** (#2C3539, #3D4B52, #5A6970): For midground elements and structures
- **Desaturated Reds** (#591C1C, #7A2828, #9E3232): For occasional accent and danger elements
- **Pale Yellows** (#D9C8A3, #BFA97C): For light sources and points of interest

### Environmental Variations
- **Industrial Areas**: Heavy on grays and metallic tones with blue undertones
- **Forest/Organic Areas**: Introduce subtle greens (#1D3B2D, #2A4A3A) while maintaining overall palette
- **Submerged Areas**: Enhanced blues with subtle caustic lighting effects
- **Shadow Realm**: Near-monochromatic with hints of purple (#1A1425, #2D2339)

## Lighting Design

### Key Lighting Principles
- **Dramatic Contrast**: Strong differences between light and shadow areas
- **Limited Light Sources**: Each scene has few, carefully placed light sources
- **Volumetric Effects**: Light beams, fog, and particles enhance depth
- **Dynamic Range**: Careful balance between visibility and atmospheric darkness

### Light Types
- **Ambient**: Minimal ambient light to maintain readability
- **Directional**: Strong key lights creating dramatic shadows
- **Point Lights**: Small, intense sources for guidance and interest
- **Volumetric**: Light shafts and fog for atmosphere and depth

## Art Elements

### Character Design
- **Protagonist**: Simple silhouette with minimal detail, slightly hunched posture
- **Proportions**: Slightly stylized with smaller head-to-body ratio than realistic
- **Animation**: Fluid, weight-driven movement with exaggerated physics
- **Detail Level**: Minimal facial features, emphasis on posture and movement

### Environment Design
- **Architecture**: Brutalist, imposing structures with decay and abandonment
- **Natural Elements**: Organic forms contrasting with rigid structures
- **Scale**: Environments dwarf the character to create sense of vulnerability
- **Layering**: Multiple depth layers (foreground, midground, background) for parallax

### Props & Objects
- **Machinery**: Angular, utilitarian designs with mysterious purpose
- **Interactive Elements**: Subtle visual cues (slight glow or distinct silhouette)
- **Hazards**: Clear visual language for dangerous elements
- **Scale Indicators**: Objects of recognizable size to establish environment scale

## Visual Effects

### Particle Systems
- **Dust**: Subtle particles in light beams and disturbed areas
- **Water**: Ripples, splashes, and underwater particles
- **Electricity**: Brief, intense flashes with minimal persistence
- **Shadow Effects**: Wispy, fluid particles for shadow manipulation mechanics

### Post-Processing
- **Vignette**: Subtle darkening at screen edges
- **Film Grain**: Very light noise texture for visual richness
- **Chromatic Aberration**: Minimal, used only in specific gameplay moments
- **Depth of Field**: Subtle background blur for focus and depth

## Animation Principles

### Character Animation
- **Weight & Physics**: Emphasis on momentum and realistic body movement
- **Anticipation**: Subtle preparation before jumps and significant actions
- **Follow-through**: Natural continuation of movement after action completion
- **Secondary Motion**: Hair, clothing, and limbs react to primary movements

### Environmental Animation
- **Subtle Movement**: Small, continuous movements in otherwise static scenes
- **Reactive Elements**: Environment responds to character presence
- **Weather Effects**: Wind, rain, or other elements enhance atmosphere
- **Machinery**: Rhythmic, purposeful movements for mechanical elements

## Technical Art Considerations

### Asset Creation
- **Modeling**: Low-poly base with normal maps for detail
- **Texturing**: Hand-painted textures with minimal tiling
- **Optimization**: LOD system for distant objects
- **Modularity**: Reusable elements with variation through composition

### Rendering Approach
- **2.5D**: 3D models rendered in a 2D side-scrolling perspective
- **Real-time Lighting**: Dynamic shadows and light interactions
- **Shader Effects**: Custom shaders for water, shadow, and atmospheric effects
- **Parallax**: Multiple depth layers moving at different speeds
